// File Name: inky.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Geonhwi Sim, Minjeong Kim, Jihyeon Song
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function Inky(x, y) {
  this.direction = createVector(0, 0);
  this.position = createVector(x, y);
  this.color = 'cyan';
  this.edible = false;
  this.edibleColor = "blue";
  this.edibleTimer = -1;
  this.comeoutTimer = 10;

  this.edibleState = function() {
    this.edible = true;
    this.edibleTimer = 0;
  }

  this.checkPortal = function() {
    if (this.position.x <= -1 && this.position.y == 13) {
      this.position.x = 20;
    } else if (this.position.x >= 21 && this.position.y == 13) {
      this.position.x = 0;
    }
  }

  this.setDirection = function(x, y) {
    this.direction.x = x;
    this.direction.y = y;
  }

  this.update = function() {
    if (frameCount % 60 == 0 && this.comeoutTimer > 0) {
      this.comeoutTimer--;
    }
    if (this.comeoutTimer == 0) {
      this.stepEdibleTimer();
      this.calculateDirection();
      this.checkCollision();
      this.position.add(this.direction);
      this.checkPortal();
    }
  }

  this.calculateDirection = function() {
    var left = !maze.contains(this.position.x - 1, this.position.y);
    var right = !maze.contains(this.position.x + 1, this.position.y);
    var up = !maze.contains(this.position.x, this.position.y - 1);
    var down = !maze.contains(this.position.x, this.position.y + 1);

    if (this.direction.x == -1 && this.direction.y == 0) {
      right = false;
    } else if (this.direction.x == 1 && this.direction.y == 0) {
      left = false;
    } else if (this.direction.x == 0 && this.direction.y == -1) {
      down = false;
    } else if (this.direction.x == 0 && this.direction.y == 1) {
      up = false;
    }

    var dirs = [];
    if (left) {
      dirs.push([-1, 0]);
    }
    if (right) {
      dirs.push([1, 0]);
    }
    if (up) {
      dirs.push([0, -1]);
    }
    if (down) {
      dirs.push([0, 1]);
    }

    if (dirs.length > 0) {
      var direction = dirs[floor(random() * dirs.length)];
      this.setDirection(direction[0], direction[1]);
    }
  }

  this.checkCollision = function() {
    var newX = this.position.x + this.direction.x;
    var newY = this.position.y + this.direction.y;
    if (maze.contains(newX, newY)) {
      this.setDirection(0, 0);
    }
  }

  this.stepEdibleTimer = function() {
    var edibleTimerLength = 20;
    if (this.edibleTimer >= 0 && this.edibleTimer < edibleTimerLength) {
      this.edibleTimer++;
    } else if (this.edibleTimer === edibleTimerLength) {
      this.edible = false;
      this.edibleTimer--;
    }

    if (this.edibleTimer == edibleTimerLength - 5) {
      this.edibleColor = this.color;
    } else if (this.edibleTimer == edibleTimerLength - 4) {
      this.edibleColor = "blue";
    } else if (this.edibleTimer == edibleTimerLength - 3) {
      this.edibleColor = this.color;
    } else if (this.edibleTimer == edibleTimerLength - 2) {
      this.edibleColor = "blue";
    } else if (this.edibleTimer == edibleTimerLength - 1) {
      this.edibleColor = this.color;
    } else if (this.edibleTimer == edibleTimerLength) {
      this.edibleColor = "blue";
    }
  }

  this.show = function() {
    push();
    strokeWeight(3 / 4 * cell);
    if (this.edible == true) {
       image(freaked_out1,(this.position.x * cell) + cell/2, (this.position.y * cell) + cell/2);
    } else {
      image(inky3,(this.position.x * cell) + cell/2, (this.position.y * cell) + cell/2);
    }
    pop();
  }
}