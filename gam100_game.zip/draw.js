
// File Name: draw.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Geonhwi Sim, Minjeong Kim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function drawScore() {

  var color = 160;
  fill(color, 0, 0);
  textSize(14);
  textFont(font);
  text('HI-SCORE', 430, 40);
  
  text('1UP', 445, 100);
  
  fill(255);
  text('10000', 460, 70);
  

  // fruit text('100', 200, 325);


  // 1.pacman eat pellet
  // if (Pacman.position.x == Pellet.x && Pacman.position.y == Pellet.y) {
  //   this.score = this.score + 10;
  // } 
//   // 2. pacman eat powerpellet
//   else if (Pacman.this.position.x == powerpelletX && Pacman.this.position.y == powerpelletY) {
//     score = score + 50;
//   } 
//   // 3. pacman eat fruit
//   else if (Pacman.this.position.x == fruitX && Pacman.this.position.y == fruitY) {
//     score = score + 100;
    
//  // score text 100
//     text('100', 200, 325);
//   } 
//   // 4. pacman eat ghost
//   else if (Pacman.this.position.x == ghostX && Pacman.this.position.y == ghostY) {  
//     score = score + 200;
//     score = score + 400;
//     score = score + 800;
//     score = score + 1600;
    
//  // score text 200, 400, 800, 1600 
//     text('200', ghostX - 10, ghostY + 20);
//     text('400', ghostX - 10, ghostY + 20);
//     text('800', ghostX - 10, ghostY + 20);
//     text('1600', ghostX - 10, ghostY + 20);
//   }

}

function drawScreen() {
  
  textFont(font);
  textSize(16);
  
  var color = 160;
  fill(color, 0, 0);
  text('HI-SCORE', 220, 50);
  text('DIGIPEN', 230, 460);
  text('1TB', 260, 490);
  
  fill(255);
  text('10000', 240, 80);
  text('1 PLAYER', 210, 310);
  text('2 PLAYERS', 210, 350);
  text('TM AND   1980 1984 NAMCO LTD.', 50, 420);
  
  image(arrow,180, 295, 15, 15);
  image(copyright,165, 405, 16, 16);
  image(logo, 0, 0, 560, 560);
}

function drawFruit() {
  image(bonusfruit, 435, 340, 27, 27);
  
  if (frameCount == 60) {
  image(bonusfruit, 210, 305, 27, 27);
  }
}

function drawLife() {
  // delet right one
  image(life, 440, 470, 27, 27);
  image(life, 470, 470, 27, 27);
  image(life, 500, 470, 27, 27);
}