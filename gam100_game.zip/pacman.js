// File Name: pacman.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Geonhwi Sim, Minjeong Kim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function Pacman () {
  this.direction = createVector(0,0);
  this.position = createVector(10, 20);

  this.checkPortal = function () {
    if (this.position.x <= -1 && this.position.y == 13) {
      this.position.x = 20;
    } else if (this.position.x >= 21 && this.position.y == 13) {
      this.position.x = 0;
    }
  }

  this.setDirection = function (x,y) {
    if (this.direction.x == 0 && this.direction.y == 0) {
      this.direction.x = x;
      this.direction.y = y;
      return;
    }

    if (x == 0 && y == 0) {
      this.direction.x = x;
      this.direction.y = y;
      return;
    }

    var movementParallel = true;
    if (this.direction.x != x && this.direction.y == y) {
      movementParallel = false;
    } else if (this.direction.x == x && this.direction.y != y) {
      movementParallel = false;
    }

    if (!movementParallel) {
        this.direction.x = x;
        this.direction.y = y;
    } else {
      var newX = this.position.x + x;
      var newY = this.position.y + y;
      if (!maze.contains(newX, newY)) {
          this.direction.x = x;
          this.direction.y = y;
      }
    }
  }

  this.update = function () {
    this.checkCollision();
    this.position.add(this.direction);
    this.checkPortal();
  }

  this.checkCollision = function () {
    var newX = this.position.x + this.direction.x;
    var newY = this.position.y + this.direction.y;
    if (maze.contains(newX, newY)) {
      this.setDirection(0,0);
    }
  }

  this.show = function () {
    image(life, (this.position.x*cell) + cell/2, (this.position.y*cell)+ cell/2);
    
    // spr_pac((this.position.x*cell) + cell, (this.position.y*cell)+ cell);
  }
}