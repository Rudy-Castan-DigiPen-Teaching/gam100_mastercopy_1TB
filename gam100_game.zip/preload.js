// File Name: preload.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Minjeong Kim, Geonhwi Sim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function preload() {
  //json
  json1 = loadJSON("assets/pacman/pacman.json");
  json2 = loadJSON("assets/ghost/FreakedOut.json");
  json3 = loadJSON("assets/ghost/blinky.json");
  json4 = loadJSON("assets/ghost/clyde.json");
  json5 = loadJSON("assets/ghost/inky.json");
  json6 = loadJSON("assets/ghost/pinky.json");
  json7 = loadJSON("assets/ghost/ghost_eaten.json");

  //png 
  logo = loadImage('assets/etc/game_logo.png');
  arrow = loadImage('assets/etc/selectarrow.png');
  copyright = loadImage('assets/etc/copyrightmark.png');
  stage = loadImage('assets/etc/map.png');
  bonusfruit = loadImage('assets/etc/bonus_fruit.png');
  pellet = loadImage('assets/etc/pellet.png');
  powerpellet = loadImage('assets/etc/power_pellet.png');

  pacman = loadImage('assets/pacman/pacman.png');
  life = loadImage('assets/pacman/pacman_life.png');

  freak = loadImage('assets/ghost/FreakedOut.png');
  blinky = loadImage('assets/ghost/blinky.png');
  clyde = loadImage('assets/ghost/clyde.png');
  inky = loadImage('assets/ghost/inky.png');
  pinky = loadImage('assets/ghost/pinky.png');
  eaten = loadImage('assets/ghost/ghost_eaten.png');

  //static png 
  blinky3 = loadImage('assets/ghost/blinky3.png');
  clyde3 = loadImage('assets/ghost/clyde3.png');
  inky3 = loadImage('assets/ghost/inky3.png');
  pinky3 = loadImage('assets/ghost/pinky3.png');
  freaked_out1 = loadImage('assets/ghost/freaked_out1.png');
  freaked_out2 = loadImage('assets/ghost/freaked_out2.png');
  
  //ttf
  font = loadFont('assets/etc/font1.ttf');

  //SFX
  sound1 = loadSound('SFX/pac_man_dies.mp3');
  sound2 = loadSound('SFX/pac_man_eat_fruit.mp3');
  sound3 = loadSound('SFX/pac_man_eat_ghost.mp3');
  sound4 = loadSound('SFX/pac_man_eat_pellet.mp3');
  sound5 = loadSound('SFX/Extra_Live.mp3');
  sound6 = loadSound('SFX/Intermission.mp3');
  sound7 = loadSound('SFX/Opening.mp3');
  sound8 = loadSound('SFX/Siren.mp3');
}