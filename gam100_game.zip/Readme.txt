Readme.txt
Create a text file named readme.txt and it must contain the following information:
URL of your project hosted by the p5.js editor (File-> Share): 
https://editor.p5js.org/das06089/sketches/qe34UMheL

Game Name and name of original company that made it: Pac-man (NES) 

Team name: 1TB

Team members (Korean name and DigiPen login ID): Minjeong Kim (minjeong.k), Jihyeon Song (jihyeon.song), GeonHwi Sim (geonhwi.sim)

GAM100F20KR 

“How to Play” instructions (The goals of the game and what to do): The goal of the game is for Pacman to eat all the pellets while avoiding four ghosts. And by eating ghosts when Pacman eats a power pellet, the player can get a high score.

Controls (What are all the buttons to play?): Up (KeyCode 38), Down (KeyCode 40), Left (KeyCode 37), Right (KeyCode 39), Enter (KeyCode 13) - Keyboard buttons. 
Players can start the game by pressing the keyboard enter button. And with the keyboard arrow buttons, the player can move the Pacman freely. If you press the up button, he goes up one space, and if you press the down button, he goes down one space, and if you press the left direction key, he goes left one space, and if you press the right direction key, he goes down one space to the right.

① D pad - Arrow key
Player can change the direction of movement with the arrow key of the keyboard.
If two or more keys are pressed at the same time, the left side have priority over the right side and the top side have priority over the bottom side in D pad.
Mainly used when the actual game starts.
② Start button - Enter
Press enter to start the game. 
On the main screen, the player does not press any button and after a certain second, the screen with the explanation appears. When you press Enter while on the explanation screen, it returns to the original main screen.

Cheat Codes (if any): We watched these videos and got some basic ideas. Then, we came up with rough codes and interfaces through team meetings.
https://www.youtube.com/watch?v=ataGotQ7ir8
https://www.youtube.com/watch?v=CeUGlSl2i4Q&list=WL&index=11
And we got a reference of ghosts’ algorithm from this site.
https://www.101computing.net/pacman-ghost-algorithm/
