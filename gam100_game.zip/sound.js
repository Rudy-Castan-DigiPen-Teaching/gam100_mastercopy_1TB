// File Name: sound.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function play1() {

  push();
  sound1.play();
  noLoop();
  pop();
}

function play2() {

  push();
  sound2.play();
  noLoop();
  pop();
}

function play3() {

  push();
  sound3.play();
  noLoop();
  pop();
}

function play4() {

  push();
  sound4.play();
  noLoop();
  pop();
}

function play5() {

  push();
  sound5.play();
  noLoop();
  pop();
}

function play6() {

  push();
  sound6.play();
  noLoop();
  pop();
}

function play7() {

  push();
  sound7.play();
  noLoop();
  pop();
}

function play8() {

  push();
  sound8.play();
  noLoop();
  pop();
}