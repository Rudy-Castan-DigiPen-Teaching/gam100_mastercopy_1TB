// File Name: map.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Geonhwi Sim, Jihyeon Song, Minjeong Kim 
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function Maze() {
  this.status = "stop";
  this.pacman = new Pacman();
  this.pinky = new Pinky(10, 12);
  this.blinky = new Blinky(10, 11);
  this.inky = new Inky(9, 12);
  this.clyde = new Clyde(11, 12);
  this.pellet = [];
  this.powerPellet = [];
  this.pacmanLife = 3;
  this.score = 0;
  this.grid = [
     [0, 0],[1, 0],[2, 0],[3, 0],[4, 0],[5, 0],[6, 0],[7, 0],[8, 0],[9, 0],[10, 0],[11, 0],[12, 0],[13, 0],[14, 0],[15, 0],[16, 0],[17, 0],[18, 0],[19, 0],[20, 0]
    ,[0, 1]                                                               ,[10, 1]                                                                        ,[20, 1]
    ,[0, 2]       ,[2, 2],[3, 2],[4, 2]       ,[6, 2],[7, 2],[8, 2]       ,[10, 2]        ,[12, 2],[13, 2],[14, 2]        ,[16, 2],[17, 2],[18, 2]        ,[20, 2]
    ,[0, 3]       ,[2, 3],[3, 3],[4, 3]       ,[6, 3],[7, 3],[8, 3]       ,[10, 3]        ,[12, 3],[13, 3],[14, 3]        ,[16, 3],[17, 3],[18, 3]        ,[20, 3]
    ,[0, 4]       ,[2, 4],[3, 4],[4, 4]       ,[6, 4],[7, 4],[8, 4]       ,[10, 4]        ,[12, 4],[13, 4],[14, 4]        ,[16, 4],[17, 4],[18, 4]        ,[20, 4]
    ,[0, 5]                                                                                                                                               ,[20, 5]
    ,[0, 6]       ,[2, 6],[3, 6],[4, 6]       ,[6, 6]       ,[8, 6],[9, 6],[10, 6],[11, 6],[12, 6]        ,[14, 6]        ,[16, 6],[17, 6],[18, 6]        ,[20, 6]
    ,[0, 7]       ,[2, 7],[3, 7],[4, 7]       ,[6, 7]       ,[8, 7],[9, 7],[10, 7],[11, 7],[12, 7]        ,[14, 7]        ,[16, 7],[17, 7],[18, 7]        ,[20, 7]
    ,[0, 8]                                   ,[6, 8]                     ,[10, 8]                        ,[14, 8]                                        ,[20, 8]
    ,[0, 9],[1, 9],[2, 9],[3, 9],[4, 9]       ,[6, 9],[7, 9],[8, 9]       ,[10, 9]        ,[12, 9],[13, 9],[14, 9]        ,[16, 9],[17, 9],[18, 9],[19, 9],[20, 9]
    ,[0,10],[1,10],[2,10],[3,10],[4,10]       ,[6,10]                                                     ,[14,10]        ,[16,10],[17,10],[18,10],[19,10],[20,10]
    ,[0,11],[1,11],[2,11],[3,11],[4,11]       ,[6,11]       ,[8,11],[9,11]        ,[11,11],[12,11]        ,[14,11]        ,[16,11],[17,11],[18,11],[19,11],[20,11]
    ,[0,12],[1,12],[2,12],[3,12],[4,12]       ,[6,12]       ,[8,12]                       ,[12,12]        ,[14,12]        ,[16,12],[17,12],[18,12],[19,12],[20,12]
                                                            ,[8,13],[9,13],[10,13],[11,13],[12,13]
    ,[0,14],[1,14],[2,14],[3,14],[4,14]       ,[6,14]       ,[8,14],[9,14],[10,14],[11,14],[12,14]        ,[14,14]        ,[16,14],[17,14],[18,14],[19,14],[20,14]
    ,[0,15],[1,15],[2,15],[3,15],[4,15]       ,[6,15]                                                     ,[14,15]        ,[16,15],[17,15],[18,15],[19,15],[20,15]
    ,[0,16],[1,16],[2,16],[3,16],[4,16]       ,[6,16]       ,[8,16],[9,16],[10,16],[11,16],[12,16]        ,[14,16]        ,[16,16],[17,16],[18,16],[19,16],[20,16]
    ,[0,17],[1,17],[2,17],[3,17],[4,17]       ,[6,17]       ,[8,17],[9,17],[10,17],[11,17],[12,17]        ,[14,17]        ,[16,17],[17,17],[18,17],[19,17],[20,17]
    ,[0,18]                                                               ,[10,18]                                                                        ,[20,18]
    ,[0,19]       ,[2,19],[3,19],[4,19]       ,[6,19],[7,19],[8,19]       ,[10,19]        ,[12,19],[13,19],[14,19]        ,[16,19],[17,19],[18,19]        ,[20,19]
    ,[0,20]                     ,[4,20]                                                                                   ,[16,20]                        ,[20,20]
    ,[0,21],[1,21],[2,21]       ,[4,21]       ,[6,21]       ,[8,21],[9,21],[10,21],[11,21],[12,21]        ,[14,21]        ,[16,21]        ,[18,21],[19,21],[20,21]
    ,[0,22],[1,22],[2,22]       ,[4,22]       ,[6,22]       ,[8,22],[9,22],[10,22],[11,22],[12,22]        ,[14,22]        ,[16,22]        ,[18,22],[19,22],[20,22]
    ,[0,23]                                   ,[6,23]                     ,[10,23]                        ,[14,23]                                        ,[20,23]
    ,[0,24]       ,[2,24],[3,24],[4,24],[5,24],[6,24],[7,24],[8,24]       ,[10,24]        ,[12,24],[13,24],[14,24],[15,24],[16,24],[17,24],[18,24]        ,[20,24]
    ,[0,25]                                                                                                                                               ,[20,25]
    ,[0,26],[1,26],[2,26],[3,26],[4,26],[5,26],[6,26],[7,26],[8,26],[9,26],[10,26],[11,26],[12,26],[13,26],[14,26],[15,26],[16,26],[17,26],[18,26],[19,26],[20,26]
  ];

  this.initialize = function() {
    this.initializeGhosts();
    this.initializePellet();
  }

  this.initializeGhosts = function() {
    this.pinky.color = "pink";
    this.blinky.color = "red";
    this.inky.color = "cyan";
    this.clyde.color = "white";
  }

  this.initializePellet = function() {
    this.pellet = [];
    for (var i = 0; i < 21; i++) {
      for (var j = 0; j < 27; j++) {
        var portal = false;
        for (var overlap1 = 0; overlap1 < 5; overlap1++) {
          portal = portal || (i == overlap1 && j == 13);
        }
        for (var overlap2 = 16; overlap2 < 21; overlap2++) {
          portal = portal || (i == overlap2 && j == 13);
        }
        for (var overlap3 = 11; overlap3 < 14; overlap3++) {
          for (var overlap4 = 9; overlap4 < 12; overlap4++) {
            portal = portal || (i == overlap4 && j == overlap3);
          }
        }
        for (var overlap5 = 10; overlap5 < 18; overlap5++) {
          portal = portal || (i == 7 && j == overlap5);
        }
        for (var overlap6 = 10; overlap6 < 18; overlap6++) {
          portal = portal || (i == 13 && j == overlap6);
        }
        for (var overlap7 = 8; overlap7 < 13; overlap7++) {
          portal = portal || (i == overlap7 && j == 10);
        }
        for (var overlap8 = 8; overlap8 < 13; overlap8++) {
          portal = portal || (i == overlap8 && j == 15);
        }
        portal = portal || (i == 6 && j == 13);
        portal = portal || (i == 14 && j == 13);
        portal = portal || (i == 9 && j == 9);
        portal = portal || (i == 11 && j == 9);

        if (portal) {
          continue;
        }

        var power = false;
        power = power || (i == 1 && j == 3);
        power = power || (i == 19 && j == 3);
        power = power || (i == 1 && j == 20);
        power = power || (i == 19 && j == 20);
        if (power) {
          var pellet = new Pellet(i, j);
          pellet.power();
          this.powerPellet.push(pellet);
          continue;
        }

        if (!this.contains(i, j)) {
          var pellets = new Pellet(i, j);
          this.pellet.push(pellets);
        }
      }
    }
  }

  this.start = function() {
    this.status = "start";
    this.pacman = new Pacman();
    this.initialize();
  }

  this.stop = function() {
    this.status = "stop";
    currentScreen = GAMEOVER;
  }
  
  this.touch = function() {
    this.pacmanLife--;
    this.pinky.position.x = 10;
    this.pinky.position.y = 12;
    this.blinky.position.x = 10;
    this.blinky.position.y = 11;
    this.inky.position.x = 9;
    this.inky.position.y = 12;
    this.clyde.position.x = 11;
    this.clyde.position.y = 12;
    this.pacman.position.x = 10;
    this.pacman.position.y = 20;
  }

  this.pinkyEdible = function() {
    this.pinky.edibleState();
  }

  this.blinkyEdible = function() {
    this.blinky.edibleState();
  }
  this.inkyEdible = function() {
    this.inky.edibleState();
  }
  this.clydeEdible = function() {
    this.clyde.edibleState();
  }

  this.eatPowerPellet = function(x, y) {
      // play4();
    for (var i = 0; i < this.powerPellet.length; i++) {
      if (this.powerPellet[i].x == x && this.powerPellet[i].y == y) {
        this.powerPellet.splice(i, 1);
        this.pinkyEdible();
        this.blinkyEdible();
        this.inkyEdible();
        this.clydeEdible();
        this.score += 50;
      }
    }
  }

  this.eatPellet = function(x, y) {
      // play4();
    for (var i = 0; i < this.pellet.length; i++) {
      if (this.pellet[i].x == x && this.pellet[i].y == y) {
        this.pellet.splice(i, 1);
        this.score += 10;
      }
    }
  }

  this.contains = function(x, y) {
    var result = false;
    for (var i = 0; i < this.grid.length; i++) {
      var wall = this.grid[i];
      if (wall[0] == x && wall[1] == y) {
        result = true;
      }
    }
    return result;
  }

  this.showPellet = function() {
    for (var i = 0; i < this.pellet.length; i++) {
      this.pellet[i].show();
    }
  }

  this.showPowerPellet = function() {
    for (var i = 0; i < this.powerPellet.length; i++) {
      this.powerPellet[i].show();
    }
  }

  this.showWalls = function() {
    image(stage, 10, -10, 600, 560);
  }

  this.showPinky = function() {
    this.pinky.show();
  }
  this.showBlinky = function() {
    this.blinky.show();
  }
  this.showInky = function() {
    this.inky.show();
  }
  this.showClyde = function() {
    this.clyde.show();
  }

  this.update = function() {
    if (this.status == "stop") {
      return;
    }
    if (this.pellet.length == 0) {
      this.initialize();
    }
    if (frameCount % 15 == 0 && !this.pinky.edible && !(this.pinky.position.y == 13 && (this.pinky.position.x < 5 || this.pinky.position.x > 15)) && !(this.blinky.position.y == 13 && (this.blinky.position.x < 5 || this.blinky.position.x > 15)) && !(this.inky.position.y == 13 && (this.inky.position.x < 5 || this.inky.position.x > 15)) && !(this.clyde.position.y == 13 && (this.clyde.position.x < 5 || this.clyde.position.x > 15))) {
      this.pacman.update();
      this.pinky.update();
      this.blinky.update();
      this.inky.update();
      this.clyde.update();
      if (this.pinky.position.x == this.pacman.position.x && this.pinky.position.y == this.pacman.position.y && this.pacmanLife > 0) {
        this.touch();
      }
      if (this.pinky.position.x == this.pacman.position.x && this.pinky.position.y == this.pacman.position.y && this.pacmanLife == 0) {
        this.stop();
      }
      if (this.blinky.position.x == this.pacman.position.x && this.blinky.position.y == this.pacman.position.y && this.pacmanLife > 0) {
        this.touch();
      }
      if (this.blinky.position.x == this.pacman.position.x && this.blinky.position.y == this.pacman.position.y && this.pacmanLife == 0) {
        this.stop();
      }
      if (this.inky.position.x == this.pacman.position.x && this.inky.position.y == this.pacman.position.y && this.pacmanLife > 0) {
        this.touch();
      }
      if (this.inky.position.x == this.pacman.position.x && this.inky.position.y == this.pacman.position.y && this.pacmanLife == 0) {
        this.stop();
      }
      if (this.clyde.position.x == this.pacman.position.x && this.clyde.position.y == this.pacman.position.y && this.pacmanLife > 0) {
        this.touch();
      }
      if (this.clyde.position.x == this.pacman.position.x && this.clyde.position.y == this.pacman.position.y && this.pacmanLife == 0) {
        this.stop();
      }
    }
    if (this.pinky.position.y == 13 && (this.pinky.position.x < 5 || this.pinky.position.x > 15) && !this.pinky.edible) {
      if ((frameCount % 30) == 0) {
        this.pinky.update();
      }
      if ((frameCount % 15) == 0) {
        this.pacman.update();
        this.blinky.update();
        this.inky.update();
        this.clyde.update();
      }
    }
    if (this.blinky.position.y == 13 && (this.blinky.position.x < 5 || this.blinky.position.x > 15) && !this.blinky.edible) {
      if ((frameCount % 30) == 0) {
        this.blinky.update();
      }
      if ((frameCount % 15) == 0) {
        this.pacman.update();
        this.pinky.update();
        this.inky.update();
        this.clyde.update();
      }
    }
    if (this.inky.position.y == 13 && (this.inky.position.x < 5 || this.inky.position.x > 15) && !this.inky.edible) {
      if ((frameCount % 30) == 0) {
        this.inky.update();
      }
      if ((frameCount % 15) == 0) {
        this.pacman.update();
        this.pinky.update();
        this.blinky.update();
        this.clyde.update();
      }
    }
    if (this.clyde.position.y == 13 && (this.clyde.position.x < 5 || this.clyde.position.x > 15) && !this.clyde.edible) {
      if ((frameCount % 30) == 0) {
        this.clyde.update();
      }
      if ((frameCount % 15) == 0) {
        this.pacman.update();
        this.pinky.update();
        this.blinky.update();
        this.inky.update();
      }
    }
    if ((frameCount & 15) == 0 && this.pinky.edible) {
      this.pacman.update();
    }
    if ((frameCount % 30) == 0 && this.pinky.edible) {
      this.pinky.update();
    }
    if (this.pinky.edible && this.pinky.position.x == this.pacman.position.x && this.pinky.position.y == this.pacman.position.y) {
      this.pinky.position.x = 10;
      this.pinky.position.y = 12;
    }
    if ((frameCount % 30) == 0 && this.blinky.edible) {
      this.blinky.update();
    }
    if (this.blinky.edible && this.blinky.position.x == this.pacman.position.x && this.blinky.position.y == this.pacman.position.y) {
      this.blinky.position.x = 10;
      this.blinky.position.y = 12;
    }
    if ((frameCount % 30) == 0 && this.inky.edible) {
      this.inky.update();
    }
    if (this.inky.edible && this.inky.position.x == this.pacman.position.x && this.inky.position.y == this.pacman.position.y) {
      this.inky.position.x = 10;
      this.inky.position.y = 12;
    }
    if ((frameCount % 30) == 0 && this.clyde.edible) {
      this.clyde.update();
    }
    if (this.clyde.edible && this.clyde.position.x == this.pacman.position.x && this.clyde.position.y == this.pacman.position.y) {
      this.clyde.position.x = 10;
      this.clyde.position.y = 12;
    }
    
    this.eatPellet(this.pacman.position.x, this.pacman.position.y);
    this.eatPowerPellet(this.pacman.position.x, this.pacman.position.y);
  }

  this.show = function() {
    this.showPellet();
    this.showPowerPellet();
    this.showWalls();
    this.showPinky();
    this.showBlinky();
    this.showInky();
    this.showClyde();
    this.pacman.show();
    
    textAlign(LEFT);
    text(this.score, 460, 130);

    if (this.status != "start") {
      push();
      fill("yellow");
      textSize(13 / 15 * cell);
      text("Ready!", 10 * cell - 30, 16 * cell + 5);
      pop();
    }
  }
}