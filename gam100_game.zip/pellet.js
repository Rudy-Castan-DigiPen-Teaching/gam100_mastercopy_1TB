// File Name: pellet.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Geonhwi Sim, Minjeong Kim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function Pellet(x, y) {
  this.x = x;
  this.y = y;
  this.type = "pellet";

  this.power = function() {
    this.type = "power";
  }

  this.show = function() {
    image(pellet, (this.x * cell) + cell / 3, (this.y * cell) + cell / 2, 27, 27);

    if (this.x == 1 && this.y == 3 || this.x == 19 && this.y == 3 || this.x == 1 && this.y == 20 || this.x == 19 && this.y == 20) {
      image(powerpellet, (this.x * cell) + cell / 3, (this.y * cell) + cell / 2, 27, 27);
    }

  }
}