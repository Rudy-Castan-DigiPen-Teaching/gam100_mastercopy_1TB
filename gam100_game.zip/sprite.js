// File Name: sprite.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Minjeong Kim, Geonhwi Sim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

function setJSON() {
  var Pacman = json1.Pacman;
  var Freak = json2.Freak;
  var Blinky = json3.Blinky;
  var Clyde = json4.Clyde;
  var Inky = json5.Inky;
  var Pinky = json6.Pinky;
  var Eaten = json7.Eaten;

  for (var b = 0; b < Blinky.length; b++) {
    createElement('2', Blinky[b]);
  }
  for (var c = 0; c < Clyde.length; c++) {
    createElement('3', Clyde[c]);
  }
  for (var d = 0; d < Inky.length; d++) {
    createElement('4', Inky[d]);
  }
  for (var e = 0; e < Pinky.length; e++) {
    createElement('5', Pinky[e]);
  }
}

function spr_pac() {
  setJSON();
  this.x = x;
  this.y = y;

  for (var a = 0; a < Pacman.length; a++) {
    let pac_pos = Pacman[a].position;
    let pac_img = pacman.get(pos.x, pos.y, pos.w, pos.h);
  }

}