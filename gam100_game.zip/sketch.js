// File Name: sketch.js
// Project Name: Pac-Man
// the Course Name: GAM100
// the Term: Fall 2020
// Author: Jihyeon Song, Geonhwi Sim, Minjeong Kim
// “All content © 2020 DigiPen (USA) Corporation, all rights reserved.”

var maze;
var cell = 20;
const MAINSCREEN = 111;
const PLAYSCREEN = 112;
const GAMEOVER = 113;
var currentScreen = MAINSCREEN;

function setup() {
  createCanvas(560, 560);
  rectMode(CORNER);
  maze = new Maze();
  maze.initialize();
}

function draw() {
  background(0);

  var rectWidth = 50;
  var rectHeight = 20;
  switch (currentScreen) {
      
    case MAINSCREEN:
      drawScreen();
      
      if (keyIsPressed === true){
        if (keyCode === 13) {
        currentScreen = PLAYSCREEN;
        }
      }
      break;

    case PLAYSCREEN:
      // play7();
      drawScore();
      drawFruit();
      drawLife();
      maze.update();
      maze.show();
      break;
      
    case GAMEOVER:
      text("Game Over", 210, height / 2);
      break;
  }
}

function reset() {
  maze.start();
}

function keyPressed() {
  var arrowKeyCodes = [37, 38, 39, 40];

  if (arrowKeyCodes.includes(keyCode) && maze.status != "start") {
    maze.start();
  }

  if (keyCode == LEFT_ARROW) {
    maze.pacman.setDirection(-1, 0);
  } else if (keyCode == RIGHT_ARROW) {
    maze.pacman.setDirection(1, 0);
  } else if (keyCode == DOWN_ARROW) {
    maze.pacman.setDirection(0, 1);
  } else if (keyCode == UP_ARROW) {
    maze.pacman.setDirection(0, -1);
  }
}